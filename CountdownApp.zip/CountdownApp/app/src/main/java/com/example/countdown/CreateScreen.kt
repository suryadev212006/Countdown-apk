package com.example.countdown

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

private fun withDate(ms: Long, y: Int, m: Int, d: Int): Long =
    Calendar.getInstance().apply { timeInMillis = ms; set(y, m, d) }.timeInMillis

private fun withTime(ms: Long, h: Int, mi: Int): Long =
    Calendar.getInstance().apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, mi)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

@Composable
fun CreateScreen(
    existing: Countdown?,
    onClose: () -> Unit,
    onSave: (Countdown) -> Unit
) {
    val ctx = LocalContext.current
    val now by rememberNow()

    var title by remember { mutableStateOf(existing?.title ?: "") }
    var allDay by remember { mutableStateOf(existing?.allDay ?: true) }
    var repeat by remember { mutableStateOf(existing?.repeat ?: "Never") }
    var bg by remember { mutableStateOf(existing?.background ?: "grad:0") }
    var font by remember { mutableStateOf(existing?.font ?: "System") }
    var target by remember {
        mutableStateOf(
            existing?.targetMillis ?: Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
        )
    }
    var repeatMenu by remember { mutableStateOf(false) }
    var showGradients by remember { mutableStateOf(false) }
    var showColors by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) BgUtil.importImage(ctx, uri)?.let { bg = "img:$it" }
    }

    val draft = Countdown(
        id = existing?.id ?: "draft",
        title = title.ifBlank { "Add a title" },
        targetMillis = target, allDay = allDay, repeat = repeat, background = bg, font = font
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = Teal) }
            Button(
                enabled = title.isNotBlank(),
                onClick = {
                    onSave(
                        Countdown(
                            id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                            title = title.trim(), targetMillis = target, allDay = allDay,
                            repeat = repeat, background = bg, font = font
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Teal, disabledContainerColor = Color(0xFF8FDCE4),
                    disabledContentColor = Color.White
                ),
                shape = RoundedCornerShape(50),
                modifier = Modifier.height(52.dp)
            ) { Text(if (existing == null) "Create" else "Save", fontSize = 20.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
        }

        CountdownCard(draft, now, height = 190.dp, showPreview = true)
        Spacer(Modifier.height(16.dp))

        Row {
            Box(Modifier.width(6.dp).height(150.dp).clip(RoundedCornerShape(3.dp)).background(Teal))
            Spacer(Modifier.width(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                TextField(
                    value = title, onValueChange = { title = it },
                    placeholder = { Text("Title", fontSize = 24.sp, color = Color.Gray) },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 24.sp),
                    colors = transparentFieldColors(),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(SoftGray)
                )
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(SoftGray).padding(16.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Start date", fontSize = 20.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                        Checkbox(
                            checked = allDay,
                            onCheckedChange = {
                                allDay = it
                                if (it) target = withTime(target, 0, 0)
                            },
                            colors = CheckboxDefaults.colors(checkedColor = Teal)
                        )
                        Text("All-day", color = Color.Gray, fontSize = 16.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PillField(longDate(target), Modifier.weight(1f)) {
                            val c = Calendar.getInstance().apply { timeInMillis = target }
                            DatePickerDialog(ctx, { _, y, m, d -> target = withDate(target, y, m, d) },
                                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                        }
                        if (!allDay) {
                            PillField(timeText(target), Modifier.width(120.dp)) {
                                val c = Calendar.getInstance().apply { timeInMillis = target }
                                TimePickerDialog(ctx, { _, h, mi -> target = withTime(target, h, mi) },
                                    c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        // Repeat
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(SoftGray)
                .clickable { repeatMenu = true }.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Repeat", fontSize = 22.sp, modifier = Modifier.weight(1f))
            Box {
                Text(repeat, fontSize = 20.sp, color = Color.Gray)
                DropdownMenu(expanded = repeatMenu, onDismissRequest = { repeatMenu = false }) {
                    listOf("Never", "Daily", "Weekly", "Monthly", "Yearly").forEach {
                        DropdownMenuItem(text = { Text(it) }, onClick = { repeat = it; repeatMenu = false })
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        // Background
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(SoftGray).padding(20.dp)) {
            Text("Background", fontSize = 22.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OptionTile("Browse", Modifier.weight(1f)) { showGradients = true }
                OptionTile("Upload", Modifier.weight(1f)) {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                OptionTile("Color", Modifier.weight(1f)) { showColors = true }
            }
        }
        Spacer(Modifier.height(16.dp))

        // Typography
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(SoftGray).padding(20.dp)) {
            Text("Typography", fontSize = 22.sp)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Clean", "System", "Serif", "Mono").forEach { f ->
                    val sel = font == f
                    Box(
                        Modifier.clip(RoundedCornerShape(50)).background(Color.White)
                            .then(if (sel) Modifier.border(2.dp, Teal, RoundedCornerShape(50)) else Modifier)
                            .clickable { font = f }
                            .padding(horizontal = 22.dp, vertical = 16.dp)
                    ) {
                        Text(
                            f, fontFamily = fontFor(f), fontSize = 18.sp, fontWeight = FontWeight.Bold,
                            color = if (sel) Teal else Color.Black
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(32.dp))
    }

    if (showGradients) {
        AlertDialog(
            onDismissRequest = { showGradients = false },
            confirmButton = { TextButton(onClick = { showGradients = false }) { Text("Done") } },
            title = { Text("Choose a background") },
            text = {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Backgrounds.gradients.indices.forEach { i ->
                        Box(
                            Modifier.size(72.dp).clip(RoundedCornerShape(16.dp))
                                .clickable { bg = "grad:$i"; showGradients = false }
                        ) { BackgroundFill("grad:$i", Modifier.fillMaxSize()) }
                    }
                }
            }
        )
    }
    if (showColors) {
        AlertDialog(
            onDismissRequest = { showColors = false },
            confirmButton = { TextButton(onClick = { showColors = false }) { Text("Done") } },
            title = { Text("Pick a color") },
            text = {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Backgrounds.colors.forEach { col ->
                        Box(
                            Modifier.size(52.dp).clip(CircleShape).background(Color(col))
                                .clickable { bg = "color:" + java.lang.Long.toHexString(col); showColors = false }
                        )
                    }
                }
            }
        )
    }
}

@Composable
private fun transparentFieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    cursorColor = Teal
)

@Composable
private fun PillField(text: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.padding(top = 8.dp).clip(RoundedCornerShape(50)).background(Color.White)
            .clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 18.dp)
    ) { Text(text, fontSize = 20.sp) }
}

@Composable
private fun OptionTile(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(80.dp).clip(RoundedCornerShape(20.dp)).background(Color.White).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 18.sp) }
}
