package com.example.countdown

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

sealed interface Screen {
    data object Home : Screen
    data class Create(val editId: String?) : Screen
    data class Detail(val id: String) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { CountdownTheme { CountdownApp() } }
    }
}

@Composable
fun CountdownApp() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var items by remember { mutableStateOf(store.load()) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

    // Ask for notification permission (Android 13+) so reminders can show
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        WidgetUpdater.updateAll(ctx)
    }

    fun upsert(c: Countdown) {
        items = items.filter { it.id != c.id } + c
        store.save(items)
        Scheduler.cancel(ctx, c.id)
        Scheduler.schedule(ctx, c)
        WidgetUpdater.updateAll(ctx)
    }

    fun delete(id: String) {
        items = items.filter { it.id != id }
        store.save(items)
        Scheduler.cancel(ctx, id)
        WidgetUpdater.updateAll(ctx)
    }

    BackHandler(enabled = screen !is Screen.Home) { screen = Screen.Home }

    val current = screen
    val bgColor = if (current is Screen.Detail) Teal else Color.White

    Box(Modifier.fillMaxSize().background(bgColor).safeDrawingPadding()) {
        when (current) {
            is Screen.Home -> HomeScreen(
                all = items,
                onAdd = { screen = Screen.Create(null) },
                onOpen = { screen = Screen.Detail(it) }
            )
            is Screen.Create -> CreateScreen(
                existing = items.firstOrNull { it.id == current.editId },
                onClose = { screen = Screen.Home },
                onSave = { upsert(it); screen = Screen.Home }
            )
            is Screen.Detail -> {
                val c = items.firstOrNull { it.id == current.id }
                if (c == null) screen = Screen.Home
                else DetailScreen(
                    c = c,
                    onBack = { screen = Screen.Home },
                    onEdit = { screen = Screen.Create(c.id) },
                    onDelete = { delete(c.id); screen = Screen.Home }
                )
            }
        }
    }
}
