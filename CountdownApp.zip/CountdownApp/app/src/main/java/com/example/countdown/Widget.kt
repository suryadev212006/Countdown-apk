package com.example.countdown

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

class CountdownWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        WidgetUpdater.update(context, mgr, ids)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == WidgetUpdater.ACTION_REFRESH) WidgetUpdater.updateAll(context)
    }
}

object WidgetUpdater {
    const val ACTION_REFRESH = "com.example.countdown.REFRESH"

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, CountdownWidgetProvider::class.java))
        if (ids.isNotEmpty()) update(ctx, mgr, ids)
    }

    /** Widget shows the nearest upcoming countdown. */
    fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val now = System.currentTimeMillis()
        val next = Store(ctx).load()
            .filter { it.effectiveTarget(now) > now }
            .minByOrNull { it.effectiveTarget(now) }

        val rv = RemoteViews(ctx.packageName, R.layout.widget_countdown)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.w_root, open)

        if (next == null) {
            rv.setImageViewBitmap(R.id.w_bg, BgUtil.widgetBitmap(ctx, "grad:0", 400))
            rv.setTextViewText(R.id.w_title, "Tap to add a countdown")
            rv.setTextViewText(R.id.w_days, "")
            rv.setViewVisibility(R.id.w_timer, View.GONE)
        } else {
            val remaining = next.effectiveTarget(now) - now
            val days = remaining / DAY_MS
            val rest = remaining % DAY_MS

            rv.setImageViewBitmap(R.id.w_bg, BgUtil.widgetBitmap(ctx, next.background, 400))
            rv.setTextViewText(R.id.w_title, next.title)
            rv.setTextViewText(R.id.w_days, if (days > 0) "$days ${if (days == 1L) "day" else "days"}" else "Today")
            rv.setViewVisibility(R.id.w_timer, View.VISIBLE)
            // Native ticking timer: counts down the hours/minutes/seconds left in the current day
            rv.setChronometerCountDown(R.id.w_timer, true)
            rv.setChronometer(R.id.w_timer, SystemClock.elapsedRealtime() + rest, null, true)

            // Refresh when the timer hits zero so the day count rolls over
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val refresh = PendingIntent.getBroadcast(
                ctx, 1,
                Intent(ctx, CountdownWidgetProvider::class.java).setAction(ACTION_REFRESH),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC, now + rest + 1500, refresh)
        }
        ids.forEach { mgr.updateAppWidget(it, rv) }
    }
}
