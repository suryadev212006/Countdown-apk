package com.example.countdown

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object Backgrounds {
    val gradients: List<Pair<Long, Long>> = listOf(
        0xFF3FBFCE to 0xFF1E6FA8,
        0xFFFF8A5B to 0xFFB83280,
        0xFF2E7D32 to 0xFFC0CA33,
        0xFF1A237E to 0xFF000000,
        0xFF8E24AA to 0xFFEC407A,
        0xFFF9A825 to 0xFFE65100
    )
    val colors: List<Long> = listOf(
        0xFF3FBFCE, 0xFF43A047, 0xFFE53935, 0xFF8E24AA,
        0xFFF9A825, 0xFF1E88E5, 0xFF37474F, 0xFFD81B60
    )

    fun gradientAt(bg: String): Pair<Long, Long> {
        val i = bg.removePrefix("grad:").toIntOrNull() ?: 0
        return gradients[i.coerceIn(0, gradients.lastIndex)]
    }

    fun colorOf(bg: String): Long =
        (bg.removePrefix("color:").toLongOrNull(16) ?: 0xFF3FBFCE) or 0xFF000000
}

object BgUtil {
    fun loadBitmap(ctx: Context, name: String, max: Int): Bitmap? {
        val f = File(ctx.filesDir, name)
        if (!f.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, bounds)
        var s = 1
        while (bounds.outWidth / s > max * 2 || bounds.outHeight / s > max * 2) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    /** Copies a picked photo into app storage (downsized) and returns the file name. */
    fun importImage(ctx: Context, uri: Uri): String? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var s = 1
            while (bounds.outWidth / s > 2200 || bounds.outHeight / s > 2200) s *= 2
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
            } ?: return null
            val name = "bg_${UUID.randomUUID()}.jpg"
            FileOutputStream(File(ctx.filesDir, name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            name
        } catch (e: Exception) {
            null
        }
    }

    /** Rounded, darkened background bitmap for the home-screen widget. */
    fun widgetBitmap(ctx: Context, bg: String, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sz = size.toFloat()
        val clip = Path().apply {
            addRoundRect(RectF(0f, 0f, sz, sz), sz * 0.14f, sz * 0.14f, Path.Direction.CW)
        }
        c.clipPath(clip)
        when {
            bg.startsWith("img:") -> {
                val src = loadBitmap(ctx, bg.removePrefix("img:"), size)
                if (src != null) {
                    val scale = maxOf(sz / src.width, sz / src.height)
                    val sw = (sz / scale).toInt()
                    val sh = (sz / scale).toInt()
                    val l = (src.width - sw) / 2
                    val t = (src.height - sh) / 2
                    c.drawBitmap(src, Rect(l, t, l + sw, t + sh), RectF(0f, 0f, sz, sz), null)
                } else c.drawColor(0xFF3FBFCE.toInt())
            }
            bg.startsWith("color:") -> c.drawColor(Backgrounds.colorOf(bg).toInt())
            else -> {
                val g = Backgrounds.gradientAt(bg)
                val p = Paint().apply {
                    shader = LinearGradient(0f, 0f, sz, sz, g.first.toInt(), g.second.toInt(), Shader.TileMode.CLAMP)
                }
                c.drawRect(0f, 0f, sz, sz, p)
            }
        }
        val scrim = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, sz, 0x22000000, 0x99000000.toInt(), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, sz, sz, scrim)
        return bmp
    }
}

@Composable
fun BackgroundFill(bg: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    when {
        bg.startsWith("img:") -> {
            val bmp = remember(bg) { BgUtil.loadBitmap(ctx, bg.removePrefix("img:"), 1080) }
            if (bmp != null) {
                Image(bmp.asImageBitmap(), null, modifier, contentScale = ContentScale.Crop)
            } else Box(modifier.background(Color(0xFF3FBFCE)))
        }
        bg.startsWith("color:") -> Box(modifier.background(Color(Backgrounds.colorOf(bg))))
        else -> {
            val g = Backgrounds.gradientAt(bg)
            Box(modifier.background(Brush.linearGradient(listOf(Color(g.first), Color(g.second)))))
        }
    }
}
