package com.example.countdown

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun shareText(ctx: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun HomeScreen(
    all: List<Countdown>,
    onAdd: () -> Unit,
    onOpen: (String) -> Unit
) {
    val ctx = LocalContext.current
    val now by rememberNow()
    var bottomTab by remember { mutableIntStateOf(0) }  // 0 Home, 1 Friends
    var topTab by remember { mutableIntStateOf(0) }     // 0 Upcoming, 1 Reached

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            if (bottomTab == 0) {
                val upcoming = all.filter { !it.isReached(now) }.sortedBy { it.effectiveTarget(now) }
                val reached = all.filter { it.isReached(now) }.sortedByDescending { it.targetMillis }
                Column(Modifier.fillMaxSize()) {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 14.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        TopTab("Upcoming", topTab == 0) { topTab = 0 }
                        Spacer(Modifier.width(40.dp))
                        TopTab("Reached", topTab == 1) { topTab = 1 }
                    }
                    val list = if (topTab == 0) upcoming else reached
                    LazyColumn(
                        Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(list, key = { it.id }) { c ->
                            CountdownCard(
                                c, now,
                                onClick = { onOpen(c.id) },
                                onShare = {
                                    val (n, u) = bigUnit(c.effectiveTarget(now) - now)
                                    shareText(ctx, "${c.title}: $n $u to go (${shortDate(c.effectiveTarget(now))})")
                                }
                            )
                        }
                        if (topTab == 0) {
                            item {
                                Box(
                                    Modifier.fillMaxWidth().height(if (list.isEmpty()) 220.dp else 160.dp)
                                        .clip(RoundedCornerShape(28.dp)).background(SoftGray)
                                        .clickable(onClick = onAdd),
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.Add, "Add", tint = Color.Gray) }
                            }
                        } else if (list.isEmpty()) {
                            item {
                                Text(
                                    "Countdowns you've reached will show up here.",
                                    color = Color.Gray, modifier = Modifier.padding(24.dp)
                                )
                            }
                        }
                    }
                }
            } else {
                FriendsTab()
            }
        }

        // Bottom bar
        Row(
            Modifier.fillMaxWidth().height(72.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomItem("Home", Icons.Default.Home, bottomTab == 0) { bottomTab = 0 }
            Box(
                Modifier.size(width = 64.dp, height = 44.dp).clip(RoundedCornerShape(14.dp))
                    .background(Teal).clickable(onClick = onAdd),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Add, "New countdown", tint = Color.White) }
            BottomItem("Friends", Icons.Default.Person, bottomTab == 1) { bottomTab = 1 }
        }
    }
}

@Composable
private fun TopTab(label: String, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            label, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            color = if (selected) Color.Black else Color.Gray
        )
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier.width(48.dp).height(4.dp).clip(RoundedCornerShape(2.dp))
                .background(if (selected) Teal else Color.Transparent)
        )
    }
}

@Composable
private fun BottomItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(Modifier.clickable(onClick = onClick).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, tint = if (selected) Color.Black else Color.Gray)
        Text(label, fontSize = 13.sp, color = if (selected) Color.Black else Color.Gray)
    }
}

@Composable
fun FriendsTab() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Friends", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Share your countdowns and count the days together.", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        Button(onClick = { shareText(ctx, "Join me on Countdown and count down the moments that matter!") }) {
            Text("Invite a friend")
        }
    }
}
