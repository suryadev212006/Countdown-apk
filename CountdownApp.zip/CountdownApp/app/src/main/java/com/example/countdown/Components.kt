package com.example.countdown

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Teal = Color(0xFF3FBFCE)
val SoftGray = Color(0xFFF0F0F0)

@Composable
fun CountdownTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Teal, onPrimary = Color.White,
            background = Color.White, surface = Color.White
        ),
        content = content
    )
}

@Composable
fun rememberNow(): State<Long> = produceState(System.currentTimeMillis()) {
    while (true) {
        value = System.currentTimeMillis()
        delay(1000)
    }
}

fun fontFor(name: String): FontFamily = when (name) {
    "Serif" -> FontFamily.Serif
    "Mono" -> FontFamily.Monospace
    "Clean" -> FontFamily.SansSerif
    else -> FontFamily.Default
}

fun shortDate(ms: Long): String = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(Date(ms))
fun longDate(ms: Long): String = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(ms))
fun timeText(ms: Long): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(ms))

/** Biggest sensible unit for the card: (number, label). */
fun bigUnit(remaining: Long): Pair<String, String> {
    val ms = remaining.coerceAtLeast(0)
    val d = ms / DAY_MS
    val h = ms / 3_600_000
    val m = ms / 60_000
    val s = ms / 1000
    fun lab(n: Long, one: String) = if (n == 1L) one else one + "s"
    return when {
        d >= 1 -> d.toString() to lab(d, "day")
        h >= 1 -> h.toString() to lab(h, "hour")
        m >= 1 -> m.toString() to lab(m, "minute")
        else -> s.toString() to lab(s, "second")
    }
}

@Composable
fun CountdownCard(
    c: Countdown,
    now: Long,
    modifier: Modifier = Modifier,
    height: Dp = 200.dp,
    showPreview: Boolean = false,
    onShare: (() -> Unit)? = null,
    onClick: (() -> Unit)? = null
) {
    val target = c.effectiveTarget(now)
    val (num, unit) = bigUnit(target - now)
    val family = fontFor(c.font)

    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(28.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        BackgroundFill(c.background, Modifier.matchParentSize())
        Box(
            Modifier.matchParentSize().background(
                Brush.verticalGradient(listOf(Color(0x22000000), Color(0x77000000)))
            )
        )
        Column(Modifier.align(Alignment.TopStart).padding(24.dp).fillMaxWidth(0.6f)) {
            Text(
                c.title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                fontFamily = family, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Text(shortDate(target), color = Color(0xCCFFFFFF), fontSize = 18.sp, fontFamily = family)
        }
        Column(
            Modifier.align(Alignment.TopEnd).padding(24.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text(num, color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Bold, fontFamily = family)
            Text(unit, color = Color(0xCCFFFFFF), fontSize = 22.sp, fontFamily = family, textAlign = TextAlign.End)
        }
        if (showPreview) {
            Text(
                "PREVIEW", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.BottomStart).padding(24.dp)
                    .border(1.dp, Color(0x99FFFFFF), RoundedCornerShape(50))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            )
        }
        if (onShare != null) {
            IconButton(
                onClick = onShare,
                modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp)
                    .clip(CircleShape).background(Color(0x44FFFFFF))
            ) { Icon(Icons.Default.Share, null, tint = Color.White) }
        }
    }
}
