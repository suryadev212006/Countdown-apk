package com.example.countdown

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID

const val DAY_MS = 24L * 60 * 60 * 1000

data class Countdown(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val targetMillis: Long,
    val allDay: Boolean,
    val repeat: String = "Never",   // Never, Daily, Weekly, Monthly, Yearly
    val background: String = "grad:0", // grad:N | color:HEX | img:filename
    val font: String = "System"     // Clean, System, Serif, Mono
) {
    /** Next moment this countdown ends, after [after]. Repeating ones roll forward. */
    fun effectiveTarget(after: Long = System.currentTimeMillis()): Long {
        if (repeat == "Never") return targetMillis
        val cal = Calendar.getInstance().apply { timeInMillis = targetMillis }
        var guard = 0
        while (cal.timeInMillis <= after && guard < 20000) {
            when (repeat) {
                "Daily" -> cal.add(Calendar.DAY_OF_YEAR, 1)
                "Weekly" -> cal.add(Calendar.WEEK_OF_YEAR, 1)
                "Monthly" -> cal.add(Calendar.MONTH, 1)
                "Yearly" -> cal.add(Calendar.YEAR, 1)
                else -> return targetMillis
            }
            guard++
        }
        return cal.timeInMillis
    }

    fun isReached(now: Long = System.currentTimeMillis()): Boolean =
        repeat == "Never" && targetMillis <= now
}

class Store(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("countdowns", Context.MODE_PRIVATE)

    fun load(): List<Countdown> {
        val raw = prefs.getString("items", "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Countdown(
                id = o.getString("id"),
                title = o.getString("title"),
                targetMillis = o.getLong("target"),
                allDay = o.getBoolean("allDay"),
                repeat = o.optString("repeat", "Never"),
                background = o.optString("bg", "grad:0"),
                font = o.optString("font", "System")
            )
        }
    }

    fun save(items: List<Countdown>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("title", it.title)
                put("target", it.targetMillis)
                put("allDay", it.allDay)
                put("repeat", it.repeat)
                put("bg", it.background)
                put("font", it.font)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
