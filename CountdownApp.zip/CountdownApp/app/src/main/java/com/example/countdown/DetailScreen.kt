package com.example.countdown

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DetailScreen(
    c: Countdown,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    val now by rememberNow()
    var menu by remember { mutableStateOf(false) }

    val remaining = (c.effectiveTarget(now) - now).coerceAtLeast(0)
    val d = remaining / DAY_MS
    val h = (remaining % DAY_MS) / 3_600_000
    val m = (remaining % 3_600_000) / 60_000
    val s = (remaining % 60_000) / 1000

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
        }
        Box {
            CountdownCardLarge(c, now)
            Box(Modifier.align(Alignment.TopEnd).padding(16.dp)) {
                IconButton(
                    onClick = { menu = true },
                    modifier = Modifier.clip(CircleShape).background(Color(0x66000000))
                ) { Icon(Icons.Default.MoreVert, "More", tint = Color.White) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit() })
                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        // Live Days / Hours / Mins / Secs
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color.White).padding(vertical = 22.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            TimeUnit(d, "Days"); TimeUnit(h, "Hours"); TimeUnit(m, "Mins"); TimeUnit(s, "Secs")
        }
        Spacer(Modifier.height(16.dp))

        // Add a friend
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color.White)
                .clickable {
                    shareText(ctx, "${c.title} is on ${longDate(c.effectiveTarget(now))}. Count down with me!")
                }
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(SoftGray),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Add, null, tint = Color.Gray) }
            Spacer(Modifier.width(18.dp))
            Column {
                Text("Add a friend", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Text("Share this countdown", color = Color.Gray, fontSize = 15.sp)
            }
        }
        Spacer(Modifier.height(16.dp))

        // Widget card
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color.White).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(150.dp).clip(RoundedCornerShape(26.dp))) {
                BackgroundFill(c.background, Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Color(0x55000000)))
                val (n, u) = bigUnit(remaining)
                Column(Modifier.align(Alignment.TopEnd).padding(12.dp), horizontalAlignment = Alignment.End) {
                    Text(n, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text(u, color = Color(0xCCFFFFFF), fontSize = 14.sp)
                }
                Text(
                    c.title, color = Color.White, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.BottomStart).padding(12.dp), maxLines = 2
                )
            }
            Spacer(Modifier.height(14.dp))
            Text("Add a countdown widget", fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Text("Moments that matter, always in sight.", color = Color.Gray, fontSize = 14.sp)
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    val mgr = AppWidgetManager.getInstance(ctx)
                    if (mgr.isRequestPinAppWidgetSupported) {
                        mgr.requestPinAppWidget(
                            ComponentName(ctx, CountdownWidgetProvider::class.java), null, null
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Teal),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Add widget now", fontSize = 17.sp) }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun CountdownCardLarge(c: Countdown, now: Long) {
    val family = fontFor(c.font)
    Box(Modifier.fillMaxWidth().height(400.dp).clip(RoundedCornerShape(28.dp))) {
        BackgroundFill(c.background, Modifier.fillMaxSize())
        Box(
            Modifier.fillMaxSize().background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(Color(0x11000000), Color(0x99000000))
                )
            )
        )
        Column(Modifier.align(Alignment.BottomStart).padding(24.dp)) {
            Text(c.title, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, fontFamily = family)
            Text(shortDate(c.effectiveTarget(now)), color = Color(0xCCFFFFFF), fontSize = 20.sp, fontFamily = family)
        }
    }
}

@Composable
private fun TimeUnit(value: Long, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value.toString(), color = Teal, fontSize = 44.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Teal, fontSize = 18.sp)
    }
}
