# Countdown App (Android, Kotlin + Jetpack Compose)

Countdown timers with a home-screen widget and reminders.

## Features
- Home with **Upcoming / Reached** tabs and a Friends tab (invite via share sheet)
- Create / edit: title, date (+ time unless All-day), Repeat (Never/Daily/Weekly/Monthly/Yearly),
  Background (Browse gradients / Upload your photo / Color), Typography (Clean/System/Serif/Mono)
- Detail screen with a live Days / Hours / Mins / Secs timer
- Home-screen widget showing the nearest countdown with a ticking timer
- Reminder notification at the exact time (survives reboot)

## Build the APK
1. Install Android Studio (Ladybug or newer) and open this folder.
2. Let Gradle sync (it downloads the SDK pieces it needs).
3. Debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   Output: `app/build/outputs/apk/debug/app-debug.apk`
4. Or from a terminal: `./gradlew assembleDebug` (Android Studio creates the wrapper on first sync).

For a Play Store / shareable release build use **Build > Generate Signed Bundle / APK**.

## Notes
- The widget shows the nearest upcoming countdown. Long-press home screen > Widgets > Countdown,
  or use "Add widget now" on a countdown's detail screen.
- Allow notifications (Android 13+) and "Alarms & reminders" for exact-time alerts.
